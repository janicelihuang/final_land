implement jumping, mass, gravity
mob distribution 
mob movement
restrict movement, borders 
